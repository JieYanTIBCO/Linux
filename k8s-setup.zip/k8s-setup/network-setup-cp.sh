#!/bin/bash

# Exit on any error
set -e

echo "[TASK 1] Configure Control Plane Network"
# Create netplan configuration
cat <<EOF | sudo tee /etc/netplan/00-installer-config.yaml
network:
  version: 2
  ethernets:
    ens33:
      dhcp4: no
      addresses:
        - 192.168.10.100/24
      gateway4: 192.168.10.2
      nameservers:
        addresses: [8.8.8.8, 8.8.4.4]
EOF

# Apply network configuration
sudo netplan apply

echo "[TASK 2] Set hostname"
sudo hostnamectl set-hostname k8s-cp

echo "[TASK 3] Install and configure dnsmasq"
sudo apt update
sudo apt install -y dnsmasq

# Backup original dnsmasq configuration
sudo cp /etc/dnsmasq.conf /etc/dnsmasq.conf.backup

# Configure dnsmasq
cat <<EOF | sudo tee /etc/dnsmasq.conf
# DNS Configuration
listen-address=127.0.0.1,192.168.10.100
domain=k8s.lab

# Static DNS entries
address=/k8s-cp.k8s.lab/192.168.10.100
address=/k8s-node1.k8s.lab/192.168.10.101
address=/k8s-node2.k8s.lab/192.168.10.102

# DHCP Configuration
dhcp-range=192.168.10.103,192.168.10.200,12h
dhcp-option=option:domain-search,k8s.lab
EOF

# Start and enable dnsmasq
sudo systemctl restart dnsmasq
sudo systemctl enable dnsmasq

echo "[TASK 4] Add local DNS entries"
cat <<EOF | sudo tee -a /etc/hosts
192.168.10.100  k8s-cp.k8s.lab  k8s-cp
192.168.10.101  k8s-node1.k8s.lab  k8s-node1
192.168.10.102  k8s-node2.k8s.lab  k8s-node2
EOF

echo "Network setup complete for control plane node!"
echo "Current IP address:"
ip addr show ens33 | grep "inet "
echo ""
echo "Testing DNS resolution:"
nslookup k8s-cp.k8s.lab
